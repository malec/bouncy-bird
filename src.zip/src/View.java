import javax.swing.JPanel;
import java.awt.*;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.Graphics;
import java.io.File;
import javax.swing.JButton;

class View extends JPanel {
    JButton b1;
    Image turtle_image;
    Model model;

    View(Controller c, Model m) {
        c.setView(this);
        model = m;
        b1 = new JButton("Self Destruct");
        b1.addActionListener(c);
        this.add(b1);
        try //To read the image in.
        {
            this.turtle_image = ImageIO.read(new File("turtle.png"));
        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public void paintComponent(Graphics g) {
        g.setColor(new Color(128, 255, 255));
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        g.drawImage(this.turtle_image, model.turtle_x,model.turtle_y, null);
    }

    void removeButton() {
        this.remove(b1);
        this.repaint();
    }
}
